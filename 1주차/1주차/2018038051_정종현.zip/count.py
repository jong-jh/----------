from collections import Counter
f = open("C://mobydick.txt", encoding="utf-8")
#d드라이브가 없어 c드라이브 안에 넣고 진행
count = Counter(f.read().split())

print("단어 출현 횟수 :", count)