import turtle
t = turtle.Turtle()
t.shape("turtle")

t.forward(100)
t.left(90)
t.forward(50)

turtle.mainloop()
turtle.bye()