import turtle
t = turtle.Turtle()

t.shape("turtle")
t.forward(100)
t.left(120)#외각이 120도, 내각은 60
t.forward(100)
t.left(120)
t.forward(100)

turtle.mainloop()
turtle.bye()